using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    //public InputManager inputManager;
    public GameManager gameManager;
    [HideInInspector]
    public SceneManager sceneManager;

    public GameObject gameMenu;

    [Header("Gameplay UI")]
    public GameObject gameplayObject;
    public TextMeshProUGUI gameResultText;
    public TextMeshProUGUI playerHealthText;
    public TextMeshProUGUI aiHealthText;

    public GameObject slot1;
    public GameObject slot2;
    public GameObject slot3;

    public GameObject CharacterPlayer;
    public GameObject CharacterIA;

    [Header("UI")]
    public GameObject optionsUI;
    public GameObject gameplayUI;

    [Header("Cards")]
    public Image[] playerCardTexts; //cambiar para imagen

    private bool optionsMenuState = false;

    private void Start()
    {
        //inputManager = FindObjectOfType<InputManager>();   ???
        //inputManager.uiManager = this;
        sceneManager = FindObjectOfType<SceneManager>();
    }

    public void StartButton()
    {
        sceneManager.NextScene();
    }

    public void OptionsButton()
    {
        if (!optionsMenuState)
        {
            optionsUI.SetActive(true);
            gameplayUI.SetActive(false);
            optionsMenuState = true;
        }
        else
        {
            optionsUI.SetActive(false);
            gameplayUI.SetActive(true);
            optionsMenuState = false;
        }
    }

    public void BackButton()
    {
        optionsUI.SetActive(false);
        gameplayUI.SetActive(true);
        optionsMenuState = false;
    }

    public void OnButtonClicked(int cardIndex)
    {
        if (cardIndex >= 0 && cardIndex < playerCardTexts.Length)
        {
            gameManager.PlayRound(cardIndex);
        }
        else
        {
            Debug.LogError("Invalid card index: " + cardIndex);
        }
    }

    public void UpdatePlayerCardsText(Attack typeAttack, int slot)
    {
        switch (slot)
        {
            case 0:
                slot1.GetComponent<Image>().sprite = Resources.Load<Sprite>(typeAttack.getImagePath()); 
                break;
            case 1:
                slot2.GetComponent<Image>().sprite = Resources.Load<Sprite>(typeAttack.getImagePath()); 
                break;
            case 2:
                slot3.GetComponent<Image>().sprite = Resources.Load<Sprite>(typeAttack.getImagePath()); 
                break;
        }
    }

    public void UpdateAvatarImage(string playerImagePath, string aiImagePath)
    {
        Debug.Log("HOla");
        Debug.Log(playerImagePath);
        Debug.Log(aiImagePath);
        Debug.Log("Primero");
        Debug.Log(CharacterPlayer);
        Debug.Log(CharacterPlayer.GetComponent<Image>());
        Debug.Log("Segundo");



        CharacterPlayer.GetComponent<Image>().sprite = Resources.Load<Sprite>(playerImagePath);
        CharacterIA.GetComponent<Image>().sprite = Resources.Load<Sprite>(aiImagePath);
    }

    public void UpdatePlayerHealthText(int health)
    {
        playerHealthText.text = health.ToString();
    }

    public void UpdateAiHealthText(int health)
    {
        aiHealthText.text = health.ToString();
    }

    public void DisplayGameWinner(CombatManager.PlayerType winner)
    {
        gameResultText.text = winner.ToString() + " Wins!";
        gameMenu.SetActive(true);
        gameplayObject.SetActive(false);
    }

    public void OnRestartButtonClicked()
    {
        sceneManager.RestartGame();
        gameMenu.SetActive(false);
        gameplayObject.SetActive(true);
    }

    public void OnMainMenuButtonClicked()
    {
        sceneManager.MainMenu();
        gameMenu.SetActive(false);
    } 

    public void Exit()
    {
        Application.Quit();
    }
}
