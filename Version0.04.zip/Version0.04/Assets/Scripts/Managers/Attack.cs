using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack 
{
    private string name;
    private string imagePath;

    public Attack(string name, string imagePath)
    {
        this.name = name;
        this.imagePath = imagePath;
    }

    public string getName() 
    {
        return name;
    }

    public string getImagePath()
    {
        return imagePath;
    }
}
