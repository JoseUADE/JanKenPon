using UnityEngine;

public class CombatManager : MonoBehaviour
{
    public GameManager gameManager;
    public UIManager uiManager;

    public int playerHealth;
    public int aiHealth;

    public enum PlayerType { Player, Ai }

    private void Start()
    {
        ResetHealth();
        uiManager.UpdateAiHealthText(aiHealth);
        uiManager.UpdatePlayerHealthText(playerHealth);
    }

    public void Attack(bool isPlayer, int damage = 1)
    {
        if (isPlayer)
        {
            aiHealth -= damage;
            uiManager.UpdateAiHealthText(aiHealth);
        }

        else if (!isPlayer)
        {
            playerHealth -= damage;
            uiManager.UpdatePlayerHealthText(playerHealth);
        }

        CheckCombatResult();
    }

    public void IncreaseHealth(PlayerType type, int amount)
    {
        if (type == PlayerType.Player)
        {
            playerHealth += amount;
        }

        else if (type == PlayerType.Ai)
        {
            aiHealth += amount;
        }
    }

    public void CheckCombatResult()
    {
        if (playerHealth <= 0)
        {
            uiManager.DisplayGameWinner(PlayerType.Ai);
        }

        else if (aiHealth <= 0)
        {
            uiManager.DisplayGameWinner(PlayerType.Player);
        }
    }

    private void ResetHealth()
    {
        playerHealth = 6;
        aiHealth = 6;
    }
}