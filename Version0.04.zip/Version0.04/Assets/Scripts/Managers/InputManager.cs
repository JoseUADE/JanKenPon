using UnityEngine;

public class InputManager : MonoBehaviour
{
    public static InputManager Instance;

    public UIManager uiManager;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        GetUIManager();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && uiManager)
        {
            uiManager.OptionsButton();
        }
        else
        {
            GetUIManager();
        }
    }

    public void GetUIManager()
    {
        uiManager = FindObjectOfType<UIManager>();
    }
}