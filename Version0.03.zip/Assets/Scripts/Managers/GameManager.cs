using UnityEngine;

public class GameManager : MonoBehaviour
{
    public UIManager uiManager;
    public CombatManager combatManager;

    public Attack[] playerCards;
    public Attack[] attacksType;

    public enum RoundResult { PlayerAttack, AIAttack, Draw }

    private const string attackName = "Attack";
    private const string shieldName = "Shield";
    private const string speedName = "Speed";

    private void Start()
    {
        FillAttacksType();
        FillPlayerCards();

        for (int i = 0; i < playerCards.Length; i++)
        {
            uiManager.UpdatePlayerCardsText(i);
        }
    }

    public void PlayRound(int playerChoiceIndex)
    {
        Attack playerChoice = playerCards[playerChoiceIndex];

        Attack aiChoice = GetRandomCard();

        DetermineRoundResult(playerChoice, aiChoice);

        UpdatePlayerCards(playerChoiceIndex);

        combatManager.CheckCombatResult();
    }

    public void FillAttacksType()
    {
        attacksType[0] = new Attack(attackName, "Assets/UI/Images/AttackToPress.png");
        attacksType[1] = new Attack(shieldName, "Assets/UI/Images/ShieldToPress.png");
        attacksType[2] = new Attack(speedName, "Assets/UI/Images/SpeedToPress.png");
    }

    public void FillPlayerCards()
    {
        for (int i = 0; i < playerCards.Length; i++)
        {
            playerCards[i] = GetRandomCard();
        }
    }

    public void UpdatePlayerCards(int usedCardIndex)
    {
        Debug.Log("Updating player card at index: " + usedCardIndex);
        Debug.Log("Player cards array size: " + playerCards.Length);

        if (usedCardIndex >= 0 && usedCardIndex < playerCards.Length)
        {
            playerCards[usedCardIndex] = GetRandomCard();
            uiManager.UpdatePlayerCardsText(usedCardIndex); //image
        }
        else
        {
            Debug.LogError("Invalid card index: " + usedCardIndex);
        }
    }

    public Attack GetRandomCard()
    {
        return attacksType[Random.Range(0, 2)]; 
    }

    private void DetermineRoundResult(Attack playerChoice, Attack aiChoice)
    {
        //if (playerChoice == aiChoice)
        //{
        //    Debug.Log("Acumular damage");
        //    return RoundResult.Draw;
        //}

        switch (playerChoice.getName(), aiChoice.getName())
        {
            case (attackName, speedName):

                combatManager.Attack(true);
                Debug.Log("Restar vida al AI 1");
                
                break;
            //return RoundResult.PlayerAttack;

            case (speedName, attackName):

                combatManager.Attack(false);
                Debug.Log("Restar vida al Player 1");

                break;
            //return RoundResult.AIAttack;

            case (shieldName, attackName):

                combatManager.Attack(true);
                Debug.Log("Restar vida al AI 2");

                break;
            //return RoundResult.PlayerAttack;

            case (attackName, shieldName):

                combatManager.Attack(false);
                Debug.Log("Restar vida al Player 2");

                break;
            //return RoundResult.AIAttack;

            case (shieldName, speedName):

                combatManager.Attack(true);
                Debug.Log("Restar vida al AI 3");

                break;
            //return RoundResult.PlayerAttack;

            case (speedName, shieldName):

                combatManager.Attack(false);
                Debug.Log("Restar vida al Player 3");

                break;
            //return RoundResult.AIAttack;

            default:

                Debug.LogWarning("Deja de buguear el juego GIL");

                break;
            //return RoundResult.Draw;
        }
    }
}