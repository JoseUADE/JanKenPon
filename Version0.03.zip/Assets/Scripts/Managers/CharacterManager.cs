using UnityEngine;

public class CharacterManager: MonoBehaviour
{
    private SceneManager sceneManager;
    private UIManager uiManager;

    public Character[] characters;
    public enum CharacterEnum { PowerHouse, Striker, PJ, Scrapper }

    public Character playerCharacter;
    public Character aiCharacter;

    private static CharacterManager instance;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        uiManager = FindObjectOfType<UIManager>();
        sceneManager = FindObjectOfType<SceneManager>();

        characters = new Character[]
        {
            new Character(CharacterEnum.PowerHouse, "imagen01"),
            new Character(CharacterEnum.Striker, "imagen02"),
            new Character(CharacterEnum.Scrapper, "imagen03"),
            new Character(CharacterEnum.PJ, "imagen04"),
        };
    }

    public void SelectPlayerAvatar(CharacterEnum selectedCharacter)
    {
        SelectAiAvatar();

        sceneManager.NextScene();

        for(int i = 0; i == characters.Length; i++)
        {
            Character currentCharacter = characters[i];

            if (currentCharacter.getCharacterId() == selectedCharacter) 
            {
                playerCharacter = currentCharacter;
            }
        }
    }

    public Character GetPlayerCharacter()
    {
        return playerCharacter;
    }

    private void SelectAiAvatar()
    {
        aiCharacter = characters[Random.Range(0, 3)];
    }
}