using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public InputManager inputManager;
    public GameManager gameManager;
    [HideInInspector]
    public SceneManager sceneManager;

    public GameObject gameMenu;

    [Header("Gameplay UI")]
    public GameObject gameplayObject;
    public TextMeshProUGUI gameResultText;
    public TextMeshProUGUI playerHealthText;
    public TextMeshProUGUI aiHealthText;

    [Header("UI")]
    public GameObject optionsUI;
    public GameObject gameplayUI;

    [Header("Cards")]
    public TextMeshProUGUI[] playerCardTexts; //cambiar para imagen

    private bool optionsMenuState = false;

    private void Start()
    {
        inputManager = FindObjectOfType<InputManager>();
        inputManager.uiManager = this;
        sceneManager = FindObjectOfType<SceneManager>();
    }

    public void StartButton()
    {
        sceneManager.NextScene();
    }

    public void OptionsButton()
    {
        if (!optionsMenuState)
        {
            optionsUI.SetActive(true);
            gameplayUI.SetActive(false);
            optionsMenuState = true;
        }
        else
        {
            optionsUI.SetActive(false);
            gameplayUI.SetActive(true);
            optionsMenuState = false;
        }
    }

    public void BackButton()
    {
        optionsUI.SetActive(false);
        gameplayUI.SetActive(true);
        optionsMenuState = false;
    }

    public void OnButtonClicked(int cardIndex)
    {
        if (cardIndex >= 0 && cardIndex < playerCardTexts.Length)
        {
            gameManager.PlayRound(cardIndex);
            //Llamar imagen cardindex
        }
        else
        {
            Debug.LogError("Invalid card index: " + cardIndex);
        }
    }

    public void UpdatePlayerCardsText(int cardIndex)
    {
        // To do, cambiar por imagen
        playerCardTexts[cardIndex].text = gameManager.playerCards[cardIndex].getImagePath();

        //Desde GameManager Retornar imagen
        /* Boton que recibe valor (Url de la imagen) = Pedir valor a un ataque de la lista player card que conoce gameManager*/
    }

    public void UpdatePlayerHealthText(int health)
    {
        playerHealthText.text = health.ToString();
    }

    public void UpdateAiHealthText(int health)
    {
        aiHealthText.text = health.ToString();
    }

    public void DisplayGameWinner(CombatManager.PlayerType winner)
    {
        gameResultText.text = winner.ToString() + " Wins!";
        gameMenu.SetActive(true);
        gameplayObject.SetActive(false);
    }

    public void OnRestartButtonClicked()
    {
        sceneManager.RestartGame();
        gameMenu.SetActive(false);
        gameplayObject.SetActive(true);
    }

    public void OnMainMenuButtonClicked()
    {
        sceneManager.MainMenu();
        gameMenu.SetActive(false);
    } 

    public void Exit()
    {
        Application.Quit();
    }
}
