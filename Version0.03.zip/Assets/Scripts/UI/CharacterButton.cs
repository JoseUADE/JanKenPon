using UnityEngine;
using UnityEngine.UI;

public class CharacterButton : MonoBehaviour
{
    public CharacterManager.CharacterEnum character;

    private CharacterManager characterSelection;

    private void Start()
    {
        characterSelection = FindObjectOfType<CharacterManager>();
        GetComponent<Button>().onClick.AddListener(SelectCharacter);
    }

    private void SelectCharacter()
    {
        characterSelection.SelectPlayerAvatar(character);
    }

    //private string image 
    //hacer contructor del boton que tenga los valores (contructor)
}