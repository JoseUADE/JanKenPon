using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character
{
    private CharacterManager.CharacterEnum characterId;
    private string imagePath;

    public Character(CharacterManager.CharacterEnum characterId, string imagePath)
    {
        this.characterId = characterId;
        this.imagePath= imagePath;
    }

    public CharacterManager.CharacterEnum getCharacterId() 
    {
        return characterId;
    }

    public string getImagePath()
    {
        return imagePath;
    }
}
 

