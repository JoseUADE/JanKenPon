using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character
{
    private CharacterManager.CharacterEnum characterId;
    private string imagePath;
    public int playerPoints = 0;

    //poner "vidas" aca
    
    //public void AddPoints(int points)
    //{
    //    playerPoints += points;
    //}

    public Character(CharacterManager.CharacterEnum characterId, string imagePath)
    {
        this.characterId = characterId;
        this.imagePath= imagePath;
    }

    public CharacterManager.CharacterEnum getCharacterId() 
    {
        return characterId;
    }

    public string getImagePath()
    {
        return imagePath;
    }
}
 

