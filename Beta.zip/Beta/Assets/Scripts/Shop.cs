using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shop : MonoBehaviour
{
    public Character player;
    public List<Product> products = new List<Product>();

    public Sprite curacionSprite;
    public Sprite fuerzaSprite;
    public Sprite energiaSprite;

    void Start()
    {
        products.Add(new Product("Curacion", 10, curacionSprite)); 
        products.Add(new Product("Fuerza", 15, fuerzaSprite));
        products.Add(new Product("Energia", 30, energiaSprite));
    }
   
    public void BuyItem(int cost)
        {
            if (player.playerPoints >= cost)
            {
                player.playerPoints -= cost;
                
                Debug.Log("Art�culo comprado");
            }
            else
            {
                Debug.Log("No tienes suficientes puntos");
            }
        }
    

}
