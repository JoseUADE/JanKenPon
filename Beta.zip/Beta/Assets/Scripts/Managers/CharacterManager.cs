using UnityEngine;
using UnityEngine.UI;

public class CharacterManager: MonoBehaviour
{
    private SceneManager sceneManager;
    private UIManager uiManager;

    public Character[] characters;
    public enum CharacterEnum {PowerHouse = 1, Striker = 2, PJ = 3, Scrapper = 4}

    public Character playerCharacter = new Character(CharacterEnum.PowerHouse, "Images/AttackToPress");
    public Character aiCharacter = new Character(CharacterEnum.PowerHouse, "Idle/PowerhouseIdle");

    public GameObject characterPlayer;  
    public GameObject characterIA;

    private static CharacterManager instance;

    

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    private void Start()
    {
        uiManager = FindObjectOfType<UIManager>();
        sceneManager = FindObjectOfType<SceneManager>();

        characters = new Character[]
        {
            new Character(CharacterEnum.PowerHouse, "Images/AttackToPress"),
            new Character(CharacterEnum.Striker, "Images/AttackToPress"),
            new Character(CharacterEnum.Scrapper, "Images/AttackToPress"),
            new Character(CharacterEnum.PJ, "Images/AttackToPress"),
        };
    }

    public void SelectPlayerAvatar(int selectedCharacter)
    {
        SelectAiAvatar();

        for(int i = 0; i == characters.Length; i++)
        {
            Character currentCharacter = characters[i];

            if (currentCharacter.getCharacterId().Equals(selectedCharacter)) 
            {
                playerCharacter = currentCharacter;
            }
        }

        uiManager.UpdateAvatarImage(playerCharacter.getImagePath(), aiCharacter.getImagePath());

        Debug.Log("aca");
        Debug.Log(sceneManager);

        sceneManager.GoToScene(2);  

        uiManager.UpdateAvatarImage(playerCharacter.getImagePath(), aiCharacter.getImagePath());
    }

    public Character GetPlayerCharacter()
    {
        return playerCharacter;
    }

    private void SelectAiAvatar()
    {
        aiCharacter = characters[Random.Range(0, 3)];
    }
}