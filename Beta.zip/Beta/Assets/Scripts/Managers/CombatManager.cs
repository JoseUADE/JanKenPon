using UnityEngine;
using UnityEngine.UI;

public class CombatManager : MonoBehaviour
{
    public static CombatManager Instance;

    public GameManager gameManager;
    public UIManager uiManager;

    public Image frontLifeBarPlayer;

    public int currentPlayerHealth;
    public int aiHealth;

    public int totalWins = 0;
    public int totalLoses = 0;

    public GameObject[] healthPlayer;
    public GameObject[] healthIA;
    

    public enum PlayerType { Player, Ai }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    private void Start()
    {
        ResetHealth();

        uiManager.UpdateAiHealthText(aiHealth);
        uiManager.UpdatePlayerHealthText(currentPlayerHealth);
    }

    public void Update()
    {
        switch (currentPlayerHealth)
        {
            case 0:
                healthPlayer[0].SetActive(true);
                healthPlayer[1].SetActive(false);
                healthPlayer[2].SetActive(false);
                healthPlayer[3].SetActive(false);
                healthPlayer[4].SetActive(false);
                healthPlayer[5].SetActive(false);
                break;
            case 1:
                healthPlayer[0].SetActive(true);
                healthPlayer[1].SetActive(true);
                healthPlayer[2].SetActive(false);
                healthPlayer[3].SetActive(false);
                healthPlayer[4].SetActive(false);
                healthPlayer[5].SetActive(false);
                break;
            case 2:
                healthPlayer[0].SetActive(true);
                healthPlayer[1].SetActive(true);
                healthPlayer[2].SetActive(true);
                healthPlayer[3].SetActive(false);
                healthPlayer[4].SetActive(false);
                healthPlayer[5].SetActive(false);
                break;
            case 3:
                healthPlayer[0].SetActive(true);
                healthPlayer[1].SetActive(true);
                healthPlayer[2].SetActive(true);
                healthPlayer[3].SetActive(true);
                healthPlayer[4].SetActive(false);
                healthPlayer[5].SetActive(false);
                break;
            case 4:
                healthPlayer[0].SetActive(true);
                healthPlayer[1].SetActive(true);
                healthPlayer[2].SetActive(true);
                healthPlayer[3].SetActive(true);
                healthPlayer[4].SetActive(true);
                healthPlayer[5].SetActive(false);
                break;
            case 5:
                healthPlayer[0].SetActive(true);
                healthPlayer[1].SetActive(true);
                healthPlayer[2].SetActive(true);
                healthPlayer[3].SetActive(true);
                healthPlayer[4].SetActive(true);
                healthPlayer[5].SetActive(true);
                break;
        }

        switch (aiHealth)
        {
            case 0:
                healthIA[0].SetActive(true);
                healthIA[1].SetActive(false);
                healthIA[2].SetActive(false);
                healthIA[3].SetActive(false);
                healthIA[4].SetActive(false);
                healthIA[5].SetActive(false);
                break;
            case 1:
                healthIA[0].SetActive(true);
                healthIA[1].SetActive(true);
                healthIA[2].SetActive(false);
                healthIA[3].SetActive(false);
                healthIA[4].SetActive(false);
                healthIA[5].SetActive(false);
                break;
            case 2:
                healthIA[0].SetActive(true);
                healthIA[1].SetActive(true);
                healthIA[2].SetActive(true);
                healthIA[3].SetActive(false);
                healthIA[4].SetActive(false);
                healthIA[5].SetActive(false);
                break;
            case 3:
                healthIA[0].SetActive(true);
                healthIA[1].SetActive(true);
                healthIA[2].SetActive(true);
                healthIA[3].SetActive(true);
                healthIA[4].SetActive(false);
                healthIA[5].SetActive(false);
                break;
            case 4:
                healthIA[0].SetActive(true);
                healthIA[1].SetActive(true);
                healthIA[2].SetActive(true);
                healthIA[3].SetActive(true);
                healthIA[4].SetActive(true);
                healthIA[5].SetActive(false);
                break;
            case 5:
                healthIA[0].SetActive(true);
                healthIA[1].SetActive(true);
                healthIA[2].SetActive(true);
                healthIA[3].SetActive(true);
                healthIA[4].SetActive(true);
                healthIA[5].SetActive(true);
                break;
        }
    }

    public void Attack(bool isPlayer, int damage = 1)
    {
        if (isPlayer)
        {
            aiHealth -= damage;
            uiManager.UpdateAiHealthText(aiHealth);
        }

        else if (!isPlayer)
        {
            currentPlayerHealth -= damage;

            uiManager.UpdatePlayerHealthText(currentPlayerHealth);
        }

        CheckCombatResult();
    }

    public void IncreaseHealth(bool isPlayer, int amount)
    {
        if (isPlayer)
        {
            currentPlayerHealth += amount;
            if (currentPlayerHealth > 5)
            {
                currentPlayerHealth = 5;
            }
            uiManager.UpdatePlayerHealthText(currentPlayerHealth);
        }

        else if (!isPlayer)
        {
            aiHealth += amount;
            if (aiHealth > 5)
            {
                aiHealth = 5;
            }
            uiManager.UpdateAiHealthText(aiHealth);
        }
    }

    public int GetWins()
    {
        return totalWins;
    }

    public int GetLoses()
    {
        return totalLoses;
    }

    public void AddWin(int score)
    {
        totalWins += score;
    }
    public void AddLose(int score)
    {
        totalLoses += score;
    }

    public void CheckCombatResult()
    {
        if (currentPlayerHealth <= 0)
        {
            uiManager.DisplayGameWinner(PlayerType.Ai);
            CombatManager.Instance.AddWin(1);
            uiManager.updateWinsAndLoses(totalWins, totalLoses);
        }

        else if (aiHealth <= 0)
        {
            uiManager.DisplayGameWinner(PlayerType.Player);
            CombatManager.Instance.AddLose(1);
            uiManager.updateWinsAndLoses(totalWins, totalLoses);
        }
    }

    

    private void ResetHealth()
    {
        currentPlayerHealth = 6;
        aiHealth = 6;
    }
}