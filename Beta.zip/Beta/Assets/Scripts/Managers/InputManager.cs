using UnityEngine;

public class InputManager : MonoBehaviour
{
    public SceneManager sceneManager;
    public static InputManager Instance;

    public UIManager uiManager;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

    }

    private void Start()
    {
        GetUIManager();
    }

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Space))
        {
            sceneManager.GoToScene(2);
        }

        if (Input.GetKeyDown(KeyCode.Escape) && uiManager)
        {
            uiManager.OptionsButton();
        }
        else
        {
            GetUIManager();
        }
    }

    public void GetUIManager()
    {
        uiManager = FindObjectOfType<UIManager>();
    }
}