using UnityEngine;

public class SceneManager : MonoBehaviour
{
    private static SceneManager instance;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    public void GoToScene(int indexScene)
    {   
        UnityEngine.SceneManagement.SceneManager.LoadScene(indexScene);
    }

    public void MainMenu()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(0);
    }
}