using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Product : MonoBehaviour
{
    public string productName;
    public int cost;
    public Sprite icon;
    
    public Product(string name, int price, Sprite productIcon)
    {
        productName = name;
        cost = price;
        icon = productIcon;
    }
}
