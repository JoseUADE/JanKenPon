using UnityEngine;

public class GameManager : MonoBehaviour
{
    public UIManager uiManager;
    public CombatManager combatManager;

    public Attack[] playerCards = new Attack[3];
    public Attack[] attacksType = new Attack[3];

    public enum RoundResult { PlayerAttack, AIAttack, Draw }

    private const string attackName = "Attack";
    private const string shieldName = "Shield";
    private const string speedName = "Speed";

    private void Start()
    {
        FillAttacksType();
        FillPlayerCards();
    }

    public void PlayRound(int playerChoiceIndex)
    {
        Attack playerChoice = playerCards[playerChoiceIndex];

        Attack aiChoice = GetRandomCard();

        DetermineRoundResult(playerChoice, aiChoice);

        UpdatePlayerCards(playerChoiceIndex);

        combatManager.CheckCombatResult();
    }

    public void FillAttacksType()
    {
        attacksType[0] = new Attack(attackName, "Images/AttackToPress");
        attacksType[1] = new Attack(shieldName, "Images/ShieldToPress");
        attacksType[2] = new Attack(speedName, "Images/SpeedToPress");
    }

    public void FillPlayerCards()
    {
        for (int i = 0; i < playerCards.Length; i++)
        {
            Attack newAttack = GetRandomCard();

            playerCards[i] = newAttack;
            uiManager.UpdatePlayerCardsText(newAttack, i);
        }
    }

    public void UpdatePlayerCards(int usedCardIndex)
    {
        Debug.Log("Updating player card at index: " + usedCardIndex);
        Debug.Log("Player cards array size: " + playerCards.Length);

        if (usedCardIndex >= 0 && usedCardIndex < playerCards.Length)
        {
            Attack newAttack = GetRandomCard();

            playerCards[usedCardIndex] = newAttack;
            uiManager.UpdatePlayerCardsText(newAttack, usedCardIndex); //image
        }
        else
        {
            Debug.LogError("Invalid card index: " + usedCardIndex);
        }
    }

    public Attack GetRandomCard()
    {
        return attacksType[Random.Range(0, 3)]; 
    }

    private void DetermineRoundResult(Attack playerChoice, Attack aiChoice)
    {
        string playerChoiceName = playerChoice.getName();
        string aiChoiceName = aiChoice.getName();

        if(attackName.Equals(playerChoiceName) && speedName.Equals(aiChoiceName))
        {
            combatManager.Attack(true);
            Debug.Log("Restar vida al AI 1");
        }

        if (speedName.Equals(playerChoiceName) && attackName.Equals(aiChoiceName))
        {
            combatManager.Attack(false);
            Debug.Log("Restar vida al Player 1");
        }

        if(shieldName.Equals(playerChoiceName) && attackName.Equals(aiChoiceName))
        {
            combatManager.Attack(true);
            Debug.Log("Restar vida al AI 2");
        }

        if (attackName.Equals(playerChoiceName) && shieldName.Equals(aiChoiceName))
        {
            combatManager.Attack(false);
            Debug.Log("Restar vida al Player 2");
        }

        if (shieldName.Equals(playerChoiceName) && speedName.Equals(aiChoiceName))
        {
            combatManager.Attack(true);
            Debug.Log("Restar vida al AI 3");
        }

        if (speedName.Equals(playerChoiceName) && shieldName.Equals(aiChoiceName))
        {
            combatManager.Attack(false);
            Debug.Log("Restar vida al Player 3");
        }
    }
}