using UnityEngine;
using UnityEngine.UI;

public class CharacterButton : MonoBehaviour
{
    public int characterID;

    private CharacterManager characterSelection;

    private void Start()
    {
        characterSelection = FindObjectOfType<CharacterManager>();
        GetComponent<Button>().onClick.AddListener(SelectCharacter);
    }

    private void SelectCharacter()
    {
        characterSelection.SelectPlayerAvatar(characterID);
    }

    //private string image 
    //hacer contructor del boton que tenga los valores (contructor)
}